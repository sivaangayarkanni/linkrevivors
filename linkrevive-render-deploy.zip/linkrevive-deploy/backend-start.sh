#!/bin/sh
# start.sh — Place in backend/ folder
# This runs DB migrations then starts the API server.
# Set as the Docker CMD or Render start command.

set -e

echo "Running Prisma migrations..."
npx prisma migrate deploy

echo "Starting LinkRevive API..."
exec node dist/server.js
