# Deploy LinkRevive to Render — Step by Step
# Repo: https://github.com/sivaangayarkanni/linkrevivor

## Step 1 — Add files to your repo

Copy these files into your repo:

  render.yaml          → repo ROOT  (sivaangayarkanni/linkrevivor/render.yaml)
  backend-start.sh     → rename to: backend/start.sh
  Dockerfile-backend-updated → replace: backend/Dockerfile

Commit and push:

  git add render.yaml backend/start.sh backend/Dockerfile
  git commit -m "add render deployment config"
  git push

## Step 2 — Deploy on Render

1. Go to https://render.com → sign up free (no credit card)
2. Click "New +" → "Blueprint"
3. Connect GitHub → select "sivaangayarkanni/linkrevivor"
4. Render detects render.yaml and shows 4 services to create:
     ✓ linkrevive-postgres  (PostgreSQL)
     ✓ linkrevive-redis     (Redis)
     ✓ linkrevive-api       (Web service)
     ✓ linkrevive-frontend  (Web service)
     ✓ linkrevive-worker    (Background worker)
5. Click "Apply" — Render provisions everything

## Step 3 — Add your API keys

After services are created, go to:
  Render Dashboard → linkrevive-api → Environment

Add these manually (they're marked sync:false for security):

  ANTHROPIC_API_KEY        = sk-ant-...
  GOOGLE_CUSTOM_SEARCH_API_KEY = (optional)
  GOOGLE_CUSTOM_SEARCH_CX     = (optional)
  GITHUB_TOKEN                 = (optional)

Then click "Save Changes" — service auto-restarts.

## Step 4 — Update CORS origin

Once frontend is deployed, Render gives it a URL like:
  https://linkrevive-frontend.onrender.com

Go to linkrevive-api → Environment → update:
  ALLOWED_ORIGINS = https://linkrevive-frontend.onrender.com

## Step 5 — Your URLs

  Frontend:  https://linkrevive-frontend.onrender.com
  API:       https://linkrevive-api.onrender.com
  Health:    https://linkrevive-api.onrender.com/health

## Notes on free tier

- Services spin down after 15min of inactivity → first request takes ~30s to wake
- Free PostgreSQL: 1GB storage, 90 days expiry (upgrade $7/mo to keep)
- Free Redis: 25MB RAM
- To avoid cold starts: upgrade API to $7/mo "Starter" plan

## Alternative: Supabase + Upstash + Render (no expiry on DB)

If you want the DB to never expire:
  PostgreSQL → https://supabase.com (free, no expiry)
  Redis      → https://upstash.com  (free, no expiry)

Get connection strings from both, then set:
  DATABASE_URL = (from Supabase → Settings → Database → Connection string)
  REDIS_URL    = (from Upstash → your database → REST URL... use the ioredis URL)

And remove the postgres + redis services from render.yaml (keep only api, worker, frontend).
